package com.crud.CRUD.model;

import lombok.Data;

@Data
public class ConnexionRequest {
    private String username;
    private String password;
}
