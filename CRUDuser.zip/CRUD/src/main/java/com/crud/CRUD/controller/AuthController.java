package com.crud.CRUD.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {

    private final AuthenticationManager authenticationManager;

    public AuthController(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String username, @RequestParam String password) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, password));
            // L'authentification a réussi
            return ResponseEntity.ok("Connexion réussie"); // Réponse avec statut 200
        } catch (AuthenticationException e) {
            // L'authentification a échoué
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Échec de la connexion : " + e.getMessage()); // Réponse avec statut 401
        }
    }
}
