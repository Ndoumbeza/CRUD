package com.crud.CRUD.controller;

import com.crud.CRUD.model.Utilisateur;
import com.crud.CRUD.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/utilisateurs")
class UtilisateurHtmlController {

    @Autowired
    private UtilisateurService utilisateurService;

    // Afficher la liste des utilisateurs
    @GetMapping
    public String afficherTousLesUtilisateurs(Model model) {
        List<Utilisateur> utilisateurs = utilisateurService.getAllUtilisateurs();
        model.addAttribute("utilisateurs", utilisateurs);
        return "utilisateurs"; // Correspond à utilisateurs.html dans /templates
    }

    // Formulaire de création d'un nouvel utilisateur
    @GetMapping("/nouveau")
    public String formulaireNouveauUtilisateur(Model model) {
        model.addAttribute("utilisateur", new Utilisateur());
        return "ajouter-utilisateur"; // Correspond à ajouter-utilisateur.html dans /templates
    }

    // Créer un nouvel utilisateur
    @PostMapping
    public String creerUtilisateur(@ModelAttribute("utilisateur") Utilisateur utilisateur) {
        utilisateurService.createUtilisateur(utilisateur); // Utilise createUtilisateur
        return "redirect:/utilisateurs"; // Redirige vers la liste des utilisateurs après ajout
    }

    // Formulaire de mise à jour d'un utilisateur
    @GetMapping("/modifier/{id}")
    public String formulaireModifierUtilisateur(@PathVariable Long id, Model model) {
        Optional<Utilisateur> utilisateur = utilisateurService.getUtilisateurById(id);
        if (utilisateur.isPresent()) {
            model.addAttribute("utilisateur", utilisateur.get());
            return "modifier-utilisateur"; // Correspond à modifier-utilisateur.html
        }
        return "redirect:/utilisateurs"; // Redirige si l'utilisateur n'existe pas
    }

    // Mettre à jour un utilisateur
    @PostMapping("/modifier/{id}")
    public String modifierUtilisateur(@PathVariable Long id, @ModelAttribute Utilisateur utilisateur) {
        utilisateurService.updateUtilisateur(id, utilisateur); // Utilise updateUtilisateur
        return "redirect:/utilisateurs";
    }

    // Supprimer un utilisateur
    @GetMapping("/supprimer/{id}")
    public String supprimerUtilisateur(@PathVariable Long id) {
        utilisateurService.deleteUtilisateur(id); // Utilise deleteUtilisateur
        return "redirect:/utilisateurs";
    }

    @PostMapping("/inscription")
public String inscrireUtilisateur(@ModelAttribute Utilisateur utilisateur) {
    utilisateurService.createUtilisateur(utilisateur); // Appelle le service pour enregistrer l'utilisateur
    return "redirect:/"; // Redirige vers la page d'accueil après inscription
}

}
