package com.crud.CRUD.config;

import com.crud.CRUD.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomUserDetailsService customUserDetailsService;

    public SecurityConfig(CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable()) // Désactivation de CSRF
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/utilisateurs/**").authenticated() // Protection des routes spécifiques
                .requestMatchers("/inscription.html", "/authentification.html").permitAll() // Permet l'accès aux pages d'inscription et d'authentification
                .anyRequest().permitAll() // Permet toutes les autres requêtes
            )
            .formLogin(form -> form
                .loginPage("/authentification.html") // Spécifiez la page de connexion personnalisée
                .permitAll() // Permet à tout le monde d'accéder à la page de connexion
            )
            .logout(logout -> logout
                .permitAll() // Permet la déconnexion à tout le monde
            );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Utilisation de BCrypt pour le hachage des mots de passe
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(customUserDetailsService); // Définition du UserDetailsService personnalisé
        authProvider.setPasswordEncoder(passwordEncoder()); // Définition de l'encodeur de mots de passe
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager(); // Gestionnaire d'authentification
    }
}
