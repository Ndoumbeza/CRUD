package com.crud.CRUD.model;

import lombok.Data;

@Data
public class InscriptionRequest {
    private String username;
    private String name;
    private String adress;
    private String password;
    // Vous pouvez ajouter d'autres attributs comme email, nom, etc.
}
