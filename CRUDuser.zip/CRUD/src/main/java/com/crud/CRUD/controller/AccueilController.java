package com.crud.CRUD.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AccueilController {

    @GetMapping("/")
    public String afficherAccueil() {
        return "accueil";  // Renvoie la page accueil.html
    }
}
