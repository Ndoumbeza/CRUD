package com.crud.CRUD.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;

public class JwtUtil {
    private final String SECRET_KEY = "votre_cle_secrete";

    public String generateToken(String username) {
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        SecretKey key = new SecretKeySpec(SECRET_KEY.getBytes(), signatureAlgorithm.getJcaName());
        
        JwtBuilder builder = Jwts.builder()
            .setSubject(username)
            .setIssuedAt(new Date())
            .signWith(key, signatureAlgorithm);

        return builder.compact();
    }

    public Claims parseToken(String token) {
        SecretKey key = new SecretKeySpec(SECRET_KEY.getBytes(), SignatureAlgorithm.HS256.getJcaName());
        return Jwts.parserBuilder()
            .setSigningKey(key)
            .build()
            .parseClaimsJws(token)
            .getBody();
    }
}
